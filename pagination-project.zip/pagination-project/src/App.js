import './App.css';
import Box from './components/Box';
import Pagination from './components/Pagination';
import SearchBar from './components/SearchBar';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useEffect, useState } from 'react';

function App() {

  const [boxData, setBoxData] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  const fetchApi = async () => {
    let data = await fetch("https://jsonplaceholder.typicode.com/posts");
    let jsonData = await data.json()
    let finalData = jsonData.filter((element, index) => {
      return index < 16;
    })
    setBoxData(finalData);
  }

  useEffect(() => {
    try{
      fetchApi();
    }
    catch(e){
      console.log("Error in fetching API");
    }
  }, [])

  return (
    <>
      <SearchBar setSearchTerm={setSearchTerm}></SearchBar>
      
      <Router>
        <Routes>
          <Route path="/" element={<Box key="1" id={0} boxData={boxData} searchTerm={searchTerm}></Box>}></Route>
          <Route path="/2" element={<Box key="2" id={1} boxData={boxData} searchTerm={searchTerm}></Box>}></Route>
          <Route path="/3" element={<Box key="3" id={2} boxData={boxData} searchTerm={searchTerm}></Box>}></Route>
          <Route path="/4" element={<Box key="4" id={3} boxData={boxData} searchTerm={searchTerm}></Box>}></Route>
        </Routes>
      </Router>
    
      <Pagination></Pagination>
    </>
  );
}

export default App;
