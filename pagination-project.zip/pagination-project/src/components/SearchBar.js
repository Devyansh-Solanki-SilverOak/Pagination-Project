function SearchBar({setSearchTerm}){
    return (
        <>
            <div className="d-flex justify-content-center p-4">
                <input className="w-25" type="text" onChange={(e) => setSearchTerm(e.target.value)} placeholder="Search here"/>
            </div>
        </>
    )
}

export default SearchBar;