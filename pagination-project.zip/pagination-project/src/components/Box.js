function Box({id, boxData, searchTerm}){

    let filteredBox = boxData.filter((element, index)=>{
        let firstIndex = id * 4;
        return (firstIndex <= index) && (firstIndex+4 > index);
    })

    let searchBox = filteredBox.filter((element)=>{
        let search = searchTerm.toLowerCase();
        let boxTitle = element.title.toLowerCase();
        let count = 0;
        for(let i=0; i<search.length; i++){
            if(boxTitle[i] == search[i]){
                count = count + 1;
            }
        }
        return count === search.length;
    })

    return (
        <>
            <div className="container">
                <div className="row my-4">
                    {
                        searchBox.map((box)=>{
                            return (
                                <div className="col-6 mb-4">
                                    <div className="box p-4 border border-primary rounded">
                                        <h3>{box.title}</h3>
                                        <p>{box.body}</p>
                                        <button className="btn btn-primary">Read More</button>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        </>
    )
}

export default Box;