import React from "react";

function Pagination(){
    return (
        <>
            <div className="container d-flex justify-content-center">
                <ul className="pagination pagination-lg">
                    <li className={`page-item`}>
                        <a className="page-link" href="/">1</a>
                    </li>
                    <li className="page-item">
                        <a className="page-link" href="/2">2</a>
                    </li>
                    <li className="page-item">
                        <a className="page-link" href="/3">3</a>
                    </li>
                    <li className="page-item">
                        <a className="page-link" href="/4">4</a>
                    </li>
                </ul>
            </div>
        </>
    )
}

export default Pagination;